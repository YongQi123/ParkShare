/**
 */
package sklearnnn;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Adam Optimizer</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see sklearnnn.SklearnnnPackage#getAdamOptimizer()
 * @model
 * @generated
 */
public interface AdamOptimizer extends BaseOptimizer {
} // AdamOptimizer
