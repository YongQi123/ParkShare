/**
 */
package sklearnnn;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Base Estimator</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see sklearnnn.SklearnnnPackage#getBaseEstimator()
 * @model abstract="true"
 * @generated
 */
public interface BaseEstimator extends component {
} // BaseEstimator
