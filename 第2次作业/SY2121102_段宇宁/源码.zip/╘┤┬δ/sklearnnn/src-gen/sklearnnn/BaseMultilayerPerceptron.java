/**
 */
package sklearnnn;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Base Multilayer Perceptron</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see sklearnnn.SklearnnnPackage#getBaseMultilayerPerceptron()
 * @model abstract="true"
 * @generated
 */
public interface BaseMultilayerPerceptron extends BaseEstimator {
} // BaseMultilayerPerceptron
