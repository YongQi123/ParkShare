/**
 */
package sklearnnn;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Base Optimizer</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see sklearnnn.SklearnnnPackage#getBaseOptimizer()
 * @model abstract="true"
 * @generated
 */
public interface BaseOptimizer extends component {
} // BaseOptimizer
