/**
 */
package sklearnnn;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Classifier Mixin</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see sklearnnn.SklearnnnPackage#getClassifierMixin()
 * @model abstract="true"
 * @generated
 */
public interface ClassifierMixin extends component {
} // ClassifierMixin
