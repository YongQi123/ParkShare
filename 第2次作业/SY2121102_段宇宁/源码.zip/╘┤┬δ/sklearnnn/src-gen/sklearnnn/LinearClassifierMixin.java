/**
 */
package sklearnnn;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Linear Classifier Mixin</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see sklearnnn.SklearnnnPackage#getLinearClassifierMixin()
 * @model abstract="true"
 * @generated
 */
public interface LinearClassifierMixin extends component {
} // LinearClassifierMixin
