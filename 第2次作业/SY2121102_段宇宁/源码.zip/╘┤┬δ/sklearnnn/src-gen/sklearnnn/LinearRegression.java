/**
 */
package sklearnnn;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Linear Regression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see sklearnnn.SklearnnnPackage#getLinearRegression()
 * @model
 * @generated
 */
public interface LinearRegression extends LinearClassifierMixin {
} // LinearRegression
