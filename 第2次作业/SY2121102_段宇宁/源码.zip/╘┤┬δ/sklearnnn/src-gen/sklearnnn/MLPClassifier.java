/**
 */
package sklearnnn;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>MLP Classifier</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see sklearnnn.SklearnnnPackage#getMLPClassifier()
 * @model
 * @generated
 */
public interface MLPClassifier extends BaseMultilayerPerceptron, ClassifierMixin {
} // MLPClassifier
