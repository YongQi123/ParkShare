/**
 */
package sklearnnn;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>MLP Regressor</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see sklearnnn.SklearnnnPackage#getMLPRegressor()
 * @model
 * @generated
 */
public interface MLPRegressor extends BaseMultilayerPerceptron, RegressorMixin {
} // MLPRegressor
