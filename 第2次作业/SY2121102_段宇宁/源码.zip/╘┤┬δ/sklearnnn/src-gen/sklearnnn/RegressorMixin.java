/**
 */
package sklearnnn;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Regressor Mixin</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see sklearnnn.SklearnnnPackage#getRegressorMixin()
 * @model abstract="true"
 * @generated
 */
public interface RegressorMixin extends component {
} // RegressorMixin
