/**
 */
package sklearnnn;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SGD Classifier</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see sklearnnn.SklearnnnPackage#getSGDClassifier()
 * @model
 * @generated
 */
public interface SGDClassifier extends LinearClassifierMixin {
} // SGDClassifier
