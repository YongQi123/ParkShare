/**
 */
package sklearnnn;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SGD Optimizer</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see sklearnnn.SklearnnnPackage#getSGDOptimizer()
 * @model
 * @generated
 */
public interface SGDOptimizer extends BaseOptimizer {
} // SGDOptimizer
