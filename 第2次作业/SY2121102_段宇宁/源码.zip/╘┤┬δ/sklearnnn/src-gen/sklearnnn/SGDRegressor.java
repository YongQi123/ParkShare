/**
 */
package sklearnnn;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SGD Regressor</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see sklearnnn.SklearnnnPackage#getSGDRegressor()
 * @model
 * @generated
 */
public interface SGDRegressor extends LinearClassifierMixin {
} // SGDRegressor
