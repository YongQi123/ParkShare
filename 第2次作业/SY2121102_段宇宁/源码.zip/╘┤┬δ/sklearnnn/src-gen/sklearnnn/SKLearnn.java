/**
 */
package sklearnnn;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SK Learnn</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link sklearnnn.SKLearnn#getName <em>Name</em>}</li>
 *   <li>{@link sklearnnn.SKLearnn#getComponent <em>Component</em>}</li>
 * </ul>
 *
 * @see sklearnnn.SklearnnnPackage#getSKLearnn()
 * @model
 * @generated
 */
public interface SKLearnn extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see sklearnnn.SklearnnnPackage#getSKLearnn_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link sklearnnn.SKLearnn#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Component</b></em>' containment reference list.
	 * The list contents are of type {@link sklearnnn.component}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Component</em>' containment reference list.
	 * @see sklearnnn.SklearnnnPackage#getSKLearnn_Component()
	 * @model containment="true"
	 * @generated
	 */
	EList<component> getComponent();

} // SKLearnn
