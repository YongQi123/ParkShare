/**
 */
package sklearnnn;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see sklearnnn.SklearnnnPackage
 * @generated
 */
public interface SklearnnnFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	SklearnnnFactory eINSTANCE = sklearnnn.impl.SklearnnnFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>SK Learnn</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>SK Learnn</em>'.
	 * @generated
	 */
	SKLearnn createSKLearnn();

	/**
	 * Returns a new object of class '<em>Linear Regression</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Linear Regression</em>'.
	 * @generated
	 */
	LinearRegression createLinearRegression();

	/**
	 * Returns a new object of class '<em>SGD Classifier</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>SGD Classifier</em>'.
	 * @generated
	 */
	SGDClassifier createSGDClassifier();

	/**
	 * Returns a new object of class '<em>SGD Regressor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>SGD Regressor</em>'.
	 * @generated
	 */
	SGDRegressor createSGDRegressor();

	/**
	 * Returns a new object of class '<em>MLP Classifier</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>MLP Classifier</em>'.
	 * @generated
	 */
	MLPClassifier createMLPClassifier();

	/**
	 * Returns a new object of class '<em>MLP Regressor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>MLP Regressor</em>'.
	 * @generated
	 */
	MLPRegressor createMLPRegressor();

	/**
	 * Returns a new object of class '<em>Adam Optimizer</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Adam Optimizer</em>'.
	 * @generated
	 */
	AdamOptimizer createAdamOptimizer();

	/**
	 * Returns a new object of class '<em>SGD Optimizer</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>SGD Optimizer</em>'.
	 * @generated
	 */
	SGDOptimizer createSGDOptimizer();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	SklearnnnPackage getSklearnnnPackage();

} //SklearnnnFactory
