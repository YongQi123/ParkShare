/**
 */
package sklearnnn;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see sklearnnn.SklearnnnFactory
 * @model kind="package"
 * @generated
 */
public interface SklearnnnPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "sklearnnn";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/sklearnnn";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "sklearnnn";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	SklearnnnPackage eINSTANCE = sklearnnn.impl.SklearnnnPackageImpl.init();

	/**
	 * The meta object id for the '{@link sklearnnn.impl.SKLearnnImpl <em>SK Learnn</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see sklearnnn.impl.SKLearnnImpl
	 * @see sklearnnn.impl.SklearnnnPackageImpl#getSKLearnn()
	 * @generated
	 */
	int SK_LEARNN = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SK_LEARNN__NAME = 0;

	/**
	 * The feature id for the '<em><b>Component</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SK_LEARNN__COMPONENT = 1;

	/**
	 * The number of structural features of the '<em>SK Learnn</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SK_LEARNN_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>SK Learnn</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SK_LEARNN_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link sklearnnn.impl.componentImpl <em>component</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see sklearnnn.impl.componentImpl
	 * @see sklearnnn.impl.SklearnnnPackageImpl#getcomponent()
	 * @generated
	 */
	int COMPONENT = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPONENT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPONENT__COMPONENT = 1;

	/**
	 * The feature id for the '<em><b>Next Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPONENT__NEXT_COMPONENT = 2;

	/**
	 * The number of structural features of the '<em>component</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPONENT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>component</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPONENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link sklearnnn.impl.LinearClassifierMixinImpl <em>Linear Classifier Mixin</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see sklearnnn.impl.LinearClassifierMixinImpl
	 * @see sklearnnn.impl.SklearnnnPackageImpl#getLinearClassifierMixin()
	 * @generated
	 */
	int LINEAR_CLASSIFIER_MIXIN = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_CLASSIFIER_MIXIN__NAME = COMPONENT__NAME;

	/**
	 * The feature id for the '<em><b>Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_CLASSIFIER_MIXIN__COMPONENT = COMPONENT__COMPONENT;

	/**
	 * The feature id for the '<em><b>Next Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_CLASSIFIER_MIXIN__NEXT_COMPONENT = COMPONENT__NEXT_COMPONENT;

	/**
	 * The number of structural features of the '<em>Linear Classifier Mixin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_CLASSIFIER_MIXIN_FEATURE_COUNT = COMPONENT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Linear Classifier Mixin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_CLASSIFIER_MIXIN_OPERATION_COUNT = COMPONENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link sklearnnn.impl.BaseEstimatorImpl <em>Base Estimator</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see sklearnnn.impl.BaseEstimatorImpl
	 * @see sklearnnn.impl.SklearnnnPackageImpl#getBaseEstimator()
	 * @generated
	 */
	int BASE_ESTIMATOR = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_ESTIMATOR__NAME = COMPONENT__NAME;

	/**
	 * The feature id for the '<em><b>Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_ESTIMATOR__COMPONENT = COMPONENT__COMPONENT;

	/**
	 * The feature id for the '<em><b>Next Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_ESTIMATOR__NEXT_COMPONENT = COMPONENT__NEXT_COMPONENT;

	/**
	 * The number of structural features of the '<em>Base Estimator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_ESTIMATOR_FEATURE_COUNT = COMPONENT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Base Estimator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_ESTIMATOR_OPERATION_COUNT = COMPONENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link sklearnnn.impl.BaseMultilayerPerceptronImpl <em>Base Multilayer Perceptron</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see sklearnnn.impl.BaseMultilayerPerceptronImpl
	 * @see sklearnnn.impl.SklearnnnPackageImpl#getBaseMultilayerPerceptron()
	 * @generated
	 */
	int BASE_MULTILAYER_PERCEPTRON = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_MULTILAYER_PERCEPTRON__NAME = BASE_ESTIMATOR__NAME;

	/**
	 * The feature id for the '<em><b>Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_MULTILAYER_PERCEPTRON__COMPONENT = BASE_ESTIMATOR__COMPONENT;

	/**
	 * The feature id for the '<em><b>Next Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_MULTILAYER_PERCEPTRON__NEXT_COMPONENT = BASE_ESTIMATOR__NEXT_COMPONENT;

	/**
	 * The number of structural features of the '<em>Base Multilayer Perceptron</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_MULTILAYER_PERCEPTRON_FEATURE_COUNT = BASE_ESTIMATOR_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Base Multilayer Perceptron</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_MULTILAYER_PERCEPTRON_OPERATION_COUNT = BASE_ESTIMATOR_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link sklearnnn.impl.ClassifierMixinImpl <em>Classifier Mixin</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see sklearnnn.impl.ClassifierMixinImpl
	 * @see sklearnnn.impl.SklearnnnPackageImpl#getClassifierMixin()
	 * @generated
	 */
	int CLASSIFIER_MIXIN = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASSIFIER_MIXIN__NAME = COMPONENT__NAME;

	/**
	 * The feature id for the '<em><b>Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASSIFIER_MIXIN__COMPONENT = COMPONENT__COMPONENT;

	/**
	 * The feature id for the '<em><b>Next Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASSIFIER_MIXIN__NEXT_COMPONENT = COMPONENT__NEXT_COMPONENT;

	/**
	 * The number of structural features of the '<em>Classifier Mixin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASSIFIER_MIXIN_FEATURE_COUNT = COMPONENT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Classifier Mixin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASSIFIER_MIXIN_OPERATION_COUNT = COMPONENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link sklearnnn.impl.RegressorMixinImpl <em>Regressor Mixin</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see sklearnnn.impl.RegressorMixinImpl
	 * @see sklearnnn.impl.SklearnnnPackageImpl#getRegressorMixin()
	 * @generated
	 */
	int REGRESSOR_MIXIN = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REGRESSOR_MIXIN__NAME = COMPONENT__NAME;

	/**
	 * The feature id for the '<em><b>Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REGRESSOR_MIXIN__COMPONENT = COMPONENT__COMPONENT;

	/**
	 * The feature id for the '<em><b>Next Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REGRESSOR_MIXIN__NEXT_COMPONENT = COMPONENT__NEXT_COMPONENT;

	/**
	 * The number of structural features of the '<em>Regressor Mixin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REGRESSOR_MIXIN_FEATURE_COUNT = COMPONENT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Regressor Mixin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REGRESSOR_MIXIN_OPERATION_COUNT = COMPONENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link sklearnnn.impl.BaseOptimizerImpl <em>Base Optimizer</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see sklearnnn.impl.BaseOptimizerImpl
	 * @see sklearnnn.impl.SklearnnnPackageImpl#getBaseOptimizer()
	 * @generated
	 */
	int BASE_OPTIMIZER = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_OPTIMIZER__NAME = COMPONENT__NAME;

	/**
	 * The feature id for the '<em><b>Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_OPTIMIZER__COMPONENT = COMPONENT__COMPONENT;

	/**
	 * The feature id for the '<em><b>Next Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_OPTIMIZER__NEXT_COMPONENT = COMPONENT__NEXT_COMPONENT;

	/**
	 * The number of structural features of the '<em>Base Optimizer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_OPTIMIZER_FEATURE_COUNT = COMPONENT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Base Optimizer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_OPTIMIZER_OPERATION_COUNT = COMPONENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link sklearnnn.impl.LinearRegressionImpl <em>Linear Regression</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see sklearnnn.impl.LinearRegressionImpl
	 * @see sklearnnn.impl.SklearnnnPackageImpl#getLinearRegression()
	 * @generated
	 */
	int LINEAR_REGRESSION = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_REGRESSION__NAME = LINEAR_CLASSIFIER_MIXIN__NAME;

	/**
	 * The feature id for the '<em><b>Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_REGRESSION__COMPONENT = LINEAR_CLASSIFIER_MIXIN__COMPONENT;

	/**
	 * The feature id for the '<em><b>Next Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_REGRESSION__NEXT_COMPONENT = LINEAR_CLASSIFIER_MIXIN__NEXT_COMPONENT;

	/**
	 * The number of structural features of the '<em>Linear Regression</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_REGRESSION_FEATURE_COUNT = LINEAR_CLASSIFIER_MIXIN_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Linear Regression</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_REGRESSION_OPERATION_COUNT = LINEAR_CLASSIFIER_MIXIN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link sklearnnn.impl.SGDClassifierImpl <em>SGD Classifier</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see sklearnnn.impl.SGDClassifierImpl
	 * @see sklearnnn.impl.SklearnnnPackageImpl#getSGDClassifier()
	 * @generated
	 */
	int SGD_CLASSIFIER = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SGD_CLASSIFIER__NAME = LINEAR_CLASSIFIER_MIXIN__NAME;

	/**
	 * The feature id for the '<em><b>Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SGD_CLASSIFIER__COMPONENT = LINEAR_CLASSIFIER_MIXIN__COMPONENT;

	/**
	 * The feature id for the '<em><b>Next Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SGD_CLASSIFIER__NEXT_COMPONENT = LINEAR_CLASSIFIER_MIXIN__NEXT_COMPONENT;

	/**
	 * The number of structural features of the '<em>SGD Classifier</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SGD_CLASSIFIER_FEATURE_COUNT = LINEAR_CLASSIFIER_MIXIN_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>SGD Classifier</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SGD_CLASSIFIER_OPERATION_COUNT = LINEAR_CLASSIFIER_MIXIN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link sklearnnn.impl.SGDRegressorImpl <em>SGD Regressor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see sklearnnn.impl.SGDRegressorImpl
	 * @see sklearnnn.impl.SklearnnnPackageImpl#getSGDRegressor()
	 * @generated
	 */
	int SGD_REGRESSOR = 10;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SGD_REGRESSOR__NAME = LINEAR_CLASSIFIER_MIXIN__NAME;

	/**
	 * The feature id for the '<em><b>Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SGD_REGRESSOR__COMPONENT = LINEAR_CLASSIFIER_MIXIN__COMPONENT;

	/**
	 * The feature id for the '<em><b>Next Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SGD_REGRESSOR__NEXT_COMPONENT = LINEAR_CLASSIFIER_MIXIN__NEXT_COMPONENT;

	/**
	 * The number of structural features of the '<em>SGD Regressor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SGD_REGRESSOR_FEATURE_COUNT = LINEAR_CLASSIFIER_MIXIN_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>SGD Regressor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SGD_REGRESSOR_OPERATION_COUNT = LINEAR_CLASSIFIER_MIXIN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link sklearnnn.impl.MLPClassifierImpl <em>MLP Classifier</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see sklearnnn.impl.MLPClassifierImpl
	 * @see sklearnnn.impl.SklearnnnPackageImpl#getMLPClassifier()
	 * @generated
	 */
	int MLP_CLASSIFIER = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MLP_CLASSIFIER__NAME = BASE_MULTILAYER_PERCEPTRON__NAME;

	/**
	 * The feature id for the '<em><b>Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MLP_CLASSIFIER__COMPONENT = BASE_MULTILAYER_PERCEPTRON__COMPONENT;

	/**
	 * The feature id for the '<em><b>Next Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MLP_CLASSIFIER__NEXT_COMPONENT = BASE_MULTILAYER_PERCEPTRON__NEXT_COMPONENT;

	/**
	 * The number of structural features of the '<em>MLP Classifier</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MLP_CLASSIFIER_FEATURE_COUNT = BASE_MULTILAYER_PERCEPTRON_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>MLP Classifier</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MLP_CLASSIFIER_OPERATION_COUNT = BASE_MULTILAYER_PERCEPTRON_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link sklearnnn.impl.MLPRegressorImpl <em>MLP Regressor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see sklearnnn.impl.MLPRegressorImpl
	 * @see sklearnnn.impl.SklearnnnPackageImpl#getMLPRegressor()
	 * @generated
	 */
	int MLP_REGRESSOR = 12;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MLP_REGRESSOR__NAME = BASE_MULTILAYER_PERCEPTRON__NAME;

	/**
	 * The feature id for the '<em><b>Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MLP_REGRESSOR__COMPONENT = BASE_MULTILAYER_PERCEPTRON__COMPONENT;

	/**
	 * The feature id for the '<em><b>Next Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MLP_REGRESSOR__NEXT_COMPONENT = BASE_MULTILAYER_PERCEPTRON__NEXT_COMPONENT;

	/**
	 * The number of structural features of the '<em>MLP Regressor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MLP_REGRESSOR_FEATURE_COUNT = BASE_MULTILAYER_PERCEPTRON_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>MLP Regressor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MLP_REGRESSOR_OPERATION_COUNT = BASE_MULTILAYER_PERCEPTRON_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link sklearnnn.impl.AdamOptimizerImpl <em>Adam Optimizer</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see sklearnnn.impl.AdamOptimizerImpl
	 * @see sklearnnn.impl.SklearnnnPackageImpl#getAdamOptimizer()
	 * @generated
	 */
	int ADAM_OPTIMIZER = 13;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAM_OPTIMIZER__NAME = BASE_OPTIMIZER__NAME;

	/**
	 * The feature id for the '<em><b>Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAM_OPTIMIZER__COMPONENT = BASE_OPTIMIZER__COMPONENT;

	/**
	 * The feature id for the '<em><b>Next Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAM_OPTIMIZER__NEXT_COMPONENT = BASE_OPTIMIZER__NEXT_COMPONENT;

	/**
	 * The number of structural features of the '<em>Adam Optimizer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAM_OPTIMIZER_FEATURE_COUNT = BASE_OPTIMIZER_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Adam Optimizer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADAM_OPTIMIZER_OPERATION_COUNT = BASE_OPTIMIZER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link sklearnnn.impl.SGDOptimizerImpl <em>SGD Optimizer</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see sklearnnn.impl.SGDOptimizerImpl
	 * @see sklearnnn.impl.SklearnnnPackageImpl#getSGDOptimizer()
	 * @generated
	 */
	int SGD_OPTIMIZER = 14;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SGD_OPTIMIZER__NAME = BASE_OPTIMIZER__NAME;

	/**
	 * The feature id for the '<em><b>Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SGD_OPTIMIZER__COMPONENT = BASE_OPTIMIZER__COMPONENT;

	/**
	 * The feature id for the '<em><b>Next Component</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SGD_OPTIMIZER__NEXT_COMPONENT = BASE_OPTIMIZER__NEXT_COMPONENT;

	/**
	 * The number of structural features of the '<em>SGD Optimizer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SGD_OPTIMIZER_FEATURE_COUNT = BASE_OPTIMIZER_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>SGD Optimizer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SGD_OPTIMIZER_OPERATION_COUNT = BASE_OPTIMIZER_OPERATION_COUNT + 0;

	/**
	 * Returns the meta object for class '{@link sklearnnn.SKLearnn <em>SK Learnn</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>SK Learnn</em>'.
	 * @see sklearnnn.SKLearnn
	 * @generated
	 */
	EClass getSKLearnn();

	/**
	 * Returns the meta object for the attribute '{@link sklearnnn.SKLearnn#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see sklearnnn.SKLearnn#getName()
	 * @see #getSKLearnn()
	 * @generated
	 */
	EAttribute getSKLearnn_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link sklearnnn.SKLearnn#getComponent <em>Component</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Component</em>'.
	 * @see sklearnnn.SKLearnn#getComponent()
	 * @see #getSKLearnn()
	 * @generated
	 */
	EReference getSKLearnn_Component();

	/**
	 * Returns the meta object for class '{@link sklearnnn.component <em>component</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>component</em>'.
	 * @see sklearnnn.component
	 * @generated
	 */
	EClass getcomponent();

	/**
	 * Returns the meta object for the attribute '{@link sklearnnn.component#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see sklearnnn.component#getName()
	 * @see #getcomponent()
	 * @generated
	 */
	EAttribute getcomponent_Name();

	/**
	 * Returns the meta object for the reference '{@link sklearnnn.component#getComponent <em>Component</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Component</em>'.
	 * @see sklearnnn.component#getComponent()
	 * @see #getcomponent()
	 * @generated
	 */
	EReference getcomponent_Component();

	/**
	 * Returns the meta object for the reference '{@link sklearnnn.component#getNextComponent <em>Next Component</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Next Component</em>'.
	 * @see sklearnnn.component#getNextComponent()
	 * @see #getcomponent()
	 * @generated
	 */
	EReference getcomponent_NextComponent();

	/**
	 * Returns the meta object for class '{@link sklearnnn.LinearClassifierMixin <em>Linear Classifier Mixin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Linear Classifier Mixin</em>'.
	 * @see sklearnnn.LinearClassifierMixin
	 * @generated
	 */
	EClass getLinearClassifierMixin();

	/**
	 * Returns the meta object for class '{@link sklearnnn.BaseMultilayerPerceptron <em>Base Multilayer Perceptron</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Base Multilayer Perceptron</em>'.
	 * @see sklearnnn.BaseMultilayerPerceptron
	 * @generated
	 */
	EClass getBaseMultilayerPerceptron();

	/**
	 * Returns the meta object for class '{@link sklearnnn.BaseEstimator <em>Base Estimator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Base Estimator</em>'.
	 * @see sklearnnn.BaseEstimator
	 * @generated
	 */
	EClass getBaseEstimator();

	/**
	 * Returns the meta object for class '{@link sklearnnn.ClassifierMixin <em>Classifier Mixin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Classifier Mixin</em>'.
	 * @see sklearnnn.ClassifierMixin
	 * @generated
	 */
	EClass getClassifierMixin();

	/**
	 * Returns the meta object for class '{@link sklearnnn.RegressorMixin <em>Regressor Mixin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Regressor Mixin</em>'.
	 * @see sklearnnn.RegressorMixin
	 * @generated
	 */
	EClass getRegressorMixin();

	/**
	 * Returns the meta object for class '{@link sklearnnn.BaseOptimizer <em>Base Optimizer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Base Optimizer</em>'.
	 * @see sklearnnn.BaseOptimizer
	 * @generated
	 */
	EClass getBaseOptimizer();

	/**
	 * Returns the meta object for class '{@link sklearnnn.LinearRegression <em>Linear Regression</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Linear Regression</em>'.
	 * @see sklearnnn.LinearRegression
	 * @generated
	 */
	EClass getLinearRegression();

	/**
	 * Returns the meta object for class '{@link sklearnnn.SGDClassifier <em>SGD Classifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>SGD Classifier</em>'.
	 * @see sklearnnn.SGDClassifier
	 * @generated
	 */
	EClass getSGDClassifier();

	/**
	 * Returns the meta object for class '{@link sklearnnn.SGDRegressor <em>SGD Regressor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>SGD Regressor</em>'.
	 * @see sklearnnn.SGDRegressor
	 * @generated
	 */
	EClass getSGDRegressor();

	/**
	 * Returns the meta object for class '{@link sklearnnn.MLPClassifier <em>MLP Classifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>MLP Classifier</em>'.
	 * @see sklearnnn.MLPClassifier
	 * @generated
	 */
	EClass getMLPClassifier();

	/**
	 * Returns the meta object for class '{@link sklearnnn.MLPRegressor <em>MLP Regressor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>MLP Regressor</em>'.
	 * @see sklearnnn.MLPRegressor
	 * @generated
	 */
	EClass getMLPRegressor();

	/**
	 * Returns the meta object for class '{@link sklearnnn.AdamOptimizer <em>Adam Optimizer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Adam Optimizer</em>'.
	 * @see sklearnnn.AdamOptimizer
	 * @generated
	 */
	EClass getAdamOptimizer();

	/**
	 * Returns the meta object for class '{@link sklearnnn.SGDOptimizer <em>SGD Optimizer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>SGD Optimizer</em>'.
	 * @see sklearnnn.SGDOptimizer
	 * @generated
	 */
	EClass getSGDOptimizer();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	SklearnnnFactory getSklearnnnFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link sklearnnn.impl.SKLearnnImpl <em>SK Learnn</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see sklearnnn.impl.SKLearnnImpl
		 * @see sklearnnn.impl.SklearnnnPackageImpl#getSKLearnn()
		 * @generated
		 */
		EClass SK_LEARNN = eINSTANCE.getSKLearnn();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SK_LEARNN__NAME = eINSTANCE.getSKLearnn_Name();

		/**
		 * The meta object literal for the '<em><b>Component</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SK_LEARNN__COMPONENT = eINSTANCE.getSKLearnn_Component();

		/**
		 * The meta object literal for the '{@link sklearnnn.impl.componentImpl <em>component</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see sklearnnn.impl.componentImpl
		 * @see sklearnnn.impl.SklearnnnPackageImpl#getcomponent()
		 * @generated
		 */
		EClass COMPONENT = eINSTANCE.getcomponent();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMPONENT__NAME = eINSTANCE.getcomponent_Name();

		/**
		 * The meta object literal for the '<em><b>Component</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPONENT__COMPONENT = eINSTANCE.getcomponent_Component();

		/**
		 * The meta object literal for the '<em><b>Next Component</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPONENT__NEXT_COMPONENT = eINSTANCE.getcomponent_NextComponent();

		/**
		 * The meta object literal for the '{@link sklearnnn.impl.LinearClassifierMixinImpl <em>Linear Classifier Mixin</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see sklearnnn.impl.LinearClassifierMixinImpl
		 * @see sklearnnn.impl.SklearnnnPackageImpl#getLinearClassifierMixin()
		 * @generated
		 */
		EClass LINEAR_CLASSIFIER_MIXIN = eINSTANCE.getLinearClassifierMixin();

		/**
		 * The meta object literal for the '{@link sklearnnn.impl.BaseMultilayerPerceptronImpl <em>Base Multilayer Perceptron</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see sklearnnn.impl.BaseMultilayerPerceptronImpl
		 * @see sklearnnn.impl.SklearnnnPackageImpl#getBaseMultilayerPerceptron()
		 * @generated
		 */
		EClass BASE_MULTILAYER_PERCEPTRON = eINSTANCE.getBaseMultilayerPerceptron();

		/**
		 * The meta object literal for the '{@link sklearnnn.impl.BaseEstimatorImpl <em>Base Estimator</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see sklearnnn.impl.BaseEstimatorImpl
		 * @see sklearnnn.impl.SklearnnnPackageImpl#getBaseEstimator()
		 * @generated
		 */
		EClass BASE_ESTIMATOR = eINSTANCE.getBaseEstimator();

		/**
		 * The meta object literal for the '{@link sklearnnn.impl.ClassifierMixinImpl <em>Classifier Mixin</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see sklearnnn.impl.ClassifierMixinImpl
		 * @see sklearnnn.impl.SklearnnnPackageImpl#getClassifierMixin()
		 * @generated
		 */
		EClass CLASSIFIER_MIXIN = eINSTANCE.getClassifierMixin();

		/**
		 * The meta object literal for the '{@link sklearnnn.impl.RegressorMixinImpl <em>Regressor Mixin</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see sklearnnn.impl.RegressorMixinImpl
		 * @see sklearnnn.impl.SklearnnnPackageImpl#getRegressorMixin()
		 * @generated
		 */
		EClass REGRESSOR_MIXIN = eINSTANCE.getRegressorMixin();

		/**
		 * The meta object literal for the '{@link sklearnnn.impl.BaseOptimizerImpl <em>Base Optimizer</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see sklearnnn.impl.BaseOptimizerImpl
		 * @see sklearnnn.impl.SklearnnnPackageImpl#getBaseOptimizer()
		 * @generated
		 */
		EClass BASE_OPTIMIZER = eINSTANCE.getBaseOptimizer();

		/**
		 * The meta object literal for the '{@link sklearnnn.impl.LinearRegressionImpl <em>Linear Regression</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see sklearnnn.impl.LinearRegressionImpl
		 * @see sklearnnn.impl.SklearnnnPackageImpl#getLinearRegression()
		 * @generated
		 */
		EClass LINEAR_REGRESSION = eINSTANCE.getLinearRegression();

		/**
		 * The meta object literal for the '{@link sklearnnn.impl.SGDClassifierImpl <em>SGD Classifier</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see sklearnnn.impl.SGDClassifierImpl
		 * @see sklearnnn.impl.SklearnnnPackageImpl#getSGDClassifier()
		 * @generated
		 */
		EClass SGD_CLASSIFIER = eINSTANCE.getSGDClassifier();

		/**
		 * The meta object literal for the '{@link sklearnnn.impl.SGDRegressorImpl <em>SGD Regressor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see sklearnnn.impl.SGDRegressorImpl
		 * @see sklearnnn.impl.SklearnnnPackageImpl#getSGDRegressor()
		 * @generated
		 */
		EClass SGD_REGRESSOR = eINSTANCE.getSGDRegressor();

		/**
		 * The meta object literal for the '{@link sklearnnn.impl.MLPClassifierImpl <em>MLP Classifier</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see sklearnnn.impl.MLPClassifierImpl
		 * @see sklearnnn.impl.SklearnnnPackageImpl#getMLPClassifier()
		 * @generated
		 */
		EClass MLP_CLASSIFIER = eINSTANCE.getMLPClassifier();

		/**
		 * The meta object literal for the '{@link sklearnnn.impl.MLPRegressorImpl <em>MLP Regressor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see sklearnnn.impl.MLPRegressorImpl
		 * @see sklearnnn.impl.SklearnnnPackageImpl#getMLPRegressor()
		 * @generated
		 */
		EClass MLP_REGRESSOR = eINSTANCE.getMLPRegressor();

		/**
		 * The meta object literal for the '{@link sklearnnn.impl.AdamOptimizerImpl <em>Adam Optimizer</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see sklearnnn.impl.AdamOptimizerImpl
		 * @see sklearnnn.impl.SklearnnnPackageImpl#getAdamOptimizer()
		 * @generated
		 */
		EClass ADAM_OPTIMIZER = eINSTANCE.getAdamOptimizer();

		/**
		 * The meta object literal for the '{@link sklearnnn.impl.SGDOptimizerImpl <em>SGD Optimizer</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see sklearnnn.impl.SGDOptimizerImpl
		 * @see sklearnnn.impl.SklearnnnPackageImpl#getSGDOptimizer()
		 * @generated
		 */
		EClass SGD_OPTIMIZER = eINSTANCE.getSGDOptimizer();

	}

} //SklearnnnPackage
