/**
 */
package sklearnnn;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>component</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link sklearnnn.component#getName <em>Name</em>}</li>
 *   <li>{@link sklearnnn.component#getComponent <em>Component</em>}</li>
 *   <li>{@link sklearnnn.component#getNextComponent <em>Next Component</em>}</li>
 * </ul>
 *
 * @see sklearnnn.SklearnnnPackage#getcomponent()
 * @model abstract="true"
 * @generated
 */
public interface component extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see sklearnnn.SklearnnnPackage#getcomponent_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link sklearnnn.component#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Component</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link sklearnnn.component#getNextComponent <em>Next Component</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Component</em>' reference.
	 * @see #setComponent(component)
	 * @see sklearnnn.SklearnnnPackage#getcomponent_Component()
	 * @see sklearnnn.component#getNextComponent
	 * @model opposite="NextComponent"
	 * @generated
	 */
	component getComponent();

	/**
	 * Sets the value of the '{@link sklearnnn.component#getComponent <em>Component</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Component</em>' reference.
	 * @see #getComponent()
	 * @generated
	 */
	void setComponent(component value);

	/**
	 * Returns the value of the '<em><b>Next Component</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link sklearnnn.component#getComponent <em>Component</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Next Component</em>' reference.
	 * @see #setNextComponent(component)
	 * @see sklearnnn.SklearnnnPackage#getcomponent_NextComponent()
	 * @see sklearnnn.component#getComponent
	 * @model opposite="component"
	 * @generated
	 */
	component getNextComponent();

	/**
	 * Sets the value of the '{@link sklearnnn.component#getNextComponent <em>Next Component</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Next Component</em>' reference.
	 * @see #getNextComponent()
	 * @generated
	 */
	void setNextComponent(component value);

} // component
