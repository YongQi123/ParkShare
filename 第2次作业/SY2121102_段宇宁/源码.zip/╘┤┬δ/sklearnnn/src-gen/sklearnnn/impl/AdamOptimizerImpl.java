/**
 */
package sklearnnn.impl;

import org.eclipse.emf.ecore.EClass;

import sklearnnn.AdamOptimizer;
import sklearnnn.SklearnnnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Adam Optimizer</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AdamOptimizerImpl extends BaseOptimizerImpl implements AdamOptimizer {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AdamOptimizerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SklearnnnPackage.Literals.ADAM_OPTIMIZER;
	}

} //AdamOptimizerImpl
