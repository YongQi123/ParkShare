/**
 */
package sklearnnn.impl;

import org.eclipse.emf.ecore.EClass;

import sklearnnn.BaseEstimator;
import sklearnnn.SklearnnnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Base Estimator</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class BaseEstimatorImpl extends componentImpl implements BaseEstimator {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BaseEstimatorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SklearnnnPackage.Literals.BASE_ESTIMATOR;
	}

} //BaseEstimatorImpl
