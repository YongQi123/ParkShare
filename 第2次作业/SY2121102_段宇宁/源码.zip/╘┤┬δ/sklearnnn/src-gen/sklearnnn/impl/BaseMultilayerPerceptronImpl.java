/**
 */
package sklearnnn.impl;

import org.eclipse.emf.ecore.EClass;

import sklearnnn.BaseMultilayerPerceptron;
import sklearnnn.SklearnnnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Base Multilayer Perceptron</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class BaseMultilayerPerceptronImpl extends BaseEstimatorImpl implements BaseMultilayerPerceptron {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BaseMultilayerPerceptronImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SklearnnnPackage.Literals.BASE_MULTILAYER_PERCEPTRON;
	}

} //BaseMultilayerPerceptronImpl
