/**
 */
package sklearnnn.impl;

import org.eclipse.emf.ecore.EClass;

import sklearnnn.BaseOptimizer;
import sklearnnn.SklearnnnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Base Optimizer</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class BaseOptimizerImpl extends componentImpl implements BaseOptimizer {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BaseOptimizerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SklearnnnPackage.Literals.BASE_OPTIMIZER;
	}

} //BaseOptimizerImpl
