/**
 */
package sklearnnn.impl;

import org.eclipse.emf.ecore.EClass;

import sklearnnn.LinearClassifierMixin;
import sklearnnn.SklearnnnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Linear Classifier Mixin</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class LinearClassifierMixinImpl extends componentImpl implements LinearClassifierMixin {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LinearClassifierMixinImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SklearnnnPackage.Literals.LINEAR_CLASSIFIER_MIXIN;
	}

} //LinearClassifierMixinImpl
