/**
 */
package sklearnnn.impl;

import org.eclipse.emf.ecore.EClass;

import sklearnnn.MLPClassifier;
import sklearnnn.SklearnnnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>MLP Classifier</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class MLPClassifierImpl extends BaseMultilayerPerceptronImpl implements MLPClassifier {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MLPClassifierImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SklearnnnPackage.Literals.MLP_CLASSIFIER;
	}

} //MLPClassifierImpl
