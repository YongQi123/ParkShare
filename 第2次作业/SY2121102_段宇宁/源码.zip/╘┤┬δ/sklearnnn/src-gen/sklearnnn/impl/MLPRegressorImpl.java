/**
 */
package sklearnnn.impl;

import org.eclipse.emf.ecore.EClass;

import sklearnnn.MLPRegressor;
import sklearnnn.SklearnnnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>MLP Regressor</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class MLPRegressorImpl extends BaseMultilayerPerceptronImpl implements MLPRegressor {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MLPRegressorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SklearnnnPackage.Literals.MLP_REGRESSOR;
	}

} //MLPRegressorImpl
