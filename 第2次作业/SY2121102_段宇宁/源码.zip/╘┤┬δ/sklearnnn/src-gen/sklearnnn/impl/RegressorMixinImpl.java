/**
 */
package sklearnnn.impl;

import org.eclipse.emf.ecore.EClass;

import sklearnnn.RegressorMixin;
import sklearnnn.SklearnnnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Regressor Mixin</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class RegressorMixinImpl extends componentImpl implements RegressorMixin {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RegressorMixinImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SklearnnnPackage.Literals.REGRESSOR_MIXIN;
	}

} //RegressorMixinImpl
