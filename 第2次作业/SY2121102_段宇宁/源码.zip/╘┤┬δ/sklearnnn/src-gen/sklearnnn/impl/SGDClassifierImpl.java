/**
 */
package sklearnnn.impl;

import org.eclipse.emf.ecore.EClass;

import sklearnnn.SGDClassifier;
import sklearnnn.SklearnnnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SGD Classifier</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SGDClassifierImpl extends LinearClassifierMixinImpl implements SGDClassifier {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SGDClassifierImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SklearnnnPackage.Literals.SGD_CLASSIFIER;
	}

} //SGDClassifierImpl
