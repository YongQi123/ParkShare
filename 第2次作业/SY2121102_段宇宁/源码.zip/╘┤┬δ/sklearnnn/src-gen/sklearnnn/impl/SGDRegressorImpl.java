/**
 */
package sklearnnn.impl;

import org.eclipse.emf.ecore.EClass;

import sklearnnn.SGDRegressor;
import sklearnnn.SklearnnnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SGD Regressor</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SGDRegressorImpl extends LinearClassifierMixinImpl implements SGDRegressor {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SGDRegressorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SklearnnnPackage.Literals.SGD_REGRESSOR;
	}

} //SGDRegressorImpl
