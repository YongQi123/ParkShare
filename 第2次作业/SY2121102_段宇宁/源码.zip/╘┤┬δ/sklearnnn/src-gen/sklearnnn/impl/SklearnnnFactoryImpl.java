/**
 */
package sklearnnn.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import sklearnnn.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class SklearnnnFactoryImpl extends EFactoryImpl implements SklearnnnFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static SklearnnnFactory init() {
		try {
			SklearnnnFactory theSklearnnnFactory = (SklearnnnFactory) EPackage.Registry.INSTANCE
					.getEFactory(SklearnnnPackage.eNS_URI);
			if (theSklearnnnFactory != null) {
				return theSklearnnnFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new SklearnnnFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SklearnnnFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case SklearnnnPackage.SK_LEARNN:
			return createSKLearnn();
		case SklearnnnPackage.LINEAR_REGRESSION:
			return createLinearRegression();
		case SklearnnnPackage.SGD_CLASSIFIER:
			return createSGDClassifier();
		case SklearnnnPackage.SGD_REGRESSOR:
			return createSGDRegressor();
		case SklearnnnPackage.MLP_CLASSIFIER:
			return createMLPClassifier();
		case SklearnnnPackage.MLP_REGRESSOR:
			return createMLPRegressor();
		case SklearnnnPackage.ADAM_OPTIMIZER:
			return createAdamOptimizer();
		case SklearnnnPackage.SGD_OPTIMIZER:
			return createSGDOptimizer();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SKLearnn createSKLearnn() {
		SKLearnnImpl skLearnn = new SKLearnnImpl();
		return skLearnn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LinearRegression createLinearRegression() {
		LinearRegressionImpl linearRegression = new LinearRegressionImpl();
		return linearRegression;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SGDClassifier createSGDClassifier() {
		SGDClassifierImpl sgdClassifier = new SGDClassifierImpl();
		return sgdClassifier;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SGDRegressor createSGDRegressor() {
		SGDRegressorImpl sgdRegressor = new SGDRegressorImpl();
		return sgdRegressor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MLPClassifier createMLPClassifier() {
		MLPClassifierImpl mlpClassifier = new MLPClassifierImpl();
		return mlpClassifier;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MLPRegressor createMLPRegressor() {
		MLPRegressorImpl mlpRegressor = new MLPRegressorImpl();
		return mlpRegressor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AdamOptimizer createAdamOptimizer() {
		AdamOptimizerImpl adamOptimizer = new AdamOptimizerImpl();
		return adamOptimizer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SGDOptimizer createSGDOptimizer() {
		SGDOptimizerImpl sgdOptimizer = new SGDOptimizerImpl();
		return sgdOptimizer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SklearnnnPackage getSklearnnnPackage() {
		return (SklearnnnPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static SklearnnnPackage getPackage() {
		return SklearnnnPackage.eINSTANCE;
	}

} //SklearnnnFactoryImpl
