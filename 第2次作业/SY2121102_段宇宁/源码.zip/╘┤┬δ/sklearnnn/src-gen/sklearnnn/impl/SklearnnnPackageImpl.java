/**
 */
package sklearnnn.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import sklearnnn.AdamOptimizer;
import sklearnnn.BaseEstimator;
import sklearnnn.BaseMultilayerPerceptron;
import sklearnnn.BaseOptimizer;
import sklearnnn.ClassifierMixin;
import sklearnnn.LinearClassifierMixin;
import sklearnnn.LinearRegression;
import sklearnnn.MLPClassifier;
import sklearnnn.MLPRegressor;
import sklearnnn.RegressorMixin;
import sklearnnn.SGDClassifier;
import sklearnnn.SGDOptimizer;
import sklearnnn.SGDRegressor;
import sklearnnn.SKLearnn;
import sklearnnn.SklearnnnFactory;
import sklearnnn.SklearnnnPackage;
import sklearnnn.component;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class SklearnnnPackageImpl extends EPackageImpl implements SklearnnnPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass skLearnnEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass componentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass linearClassifierMixinEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass baseMultilayerPerceptronEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass baseEstimatorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass classifierMixinEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass regressorMixinEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass baseOptimizerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass linearRegressionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sgdClassifierEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sgdRegressorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mlpClassifierEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mlpRegressorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass adamOptimizerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sgdOptimizerEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see sklearnnn.SklearnnnPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private SklearnnnPackageImpl() {
		super(eNS_URI, SklearnnnFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link SklearnnnPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static SklearnnnPackage init() {
		if (isInited)
			return (SklearnnnPackage) EPackage.Registry.INSTANCE.getEPackage(SklearnnnPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredSklearnnnPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		SklearnnnPackageImpl theSklearnnnPackage = registeredSklearnnnPackage instanceof SklearnnnPackageImpl
				? (SklearnnnPackageImpl) registeredSklearnnnPackage
				: new SklearnnnPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theSklearnnnPackage.createPackageContents();

		// Initialize created meta-data
		theSklearnnnPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theSklearnnnPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(SklearnnnPackage.eNS_URI, theSklearnnnPackage);
		return theSklearnnnPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSKLearnn() {
		return skLearnnEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSKLearnn_Name() {
		return (EAttribute) skLearnnEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSKLearnn_Component() {
		return (EReference) skLearnnEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getcomponent() {
		return componentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getcomponent_Name() {
		return (EAttribute) componentEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getcomponent_Component() {
		return (EReference) componentEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getcomponent_NextComponent() {
		return (EReference) componentEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getLinearClassifierMixin() {
		return linearClassifierMixinEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBaseMultilayerPerceptron() {
		return baseMultilayerPerceptronEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBaseEstimator() {
		return baseEstimatorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getClassifierMixin() {
		return classifierMixinEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRegressorMixin() {
		return regressorMixinEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBaseOptimizer() {
		return baseOptimizerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getLinearRegression() {
		return linearRegressionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSGDClassifier() {
		return sgdClassifierEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSGDRegressor() {
		return sgdRegressorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMLPClassifier() {
		return mlpClassifierEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMLPRegressor() {
		return mlpRegressorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAdamOptimizer() {
		return adamOptimizerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSGDOptimizer() {
		return sgdOptimizerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SklearnnnFactory getSklearnnnFactory() {
		return (SklearnnnFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		skLearnnEClass = createEClass(SK_LEARNN);
		createEAttribute(skLearnnEClass, SK_LEARNN__NAME);
		createEReference(skLearnnEClass, SK_LEARNN__COMPONENT);

		componentEClass = createEClass(COMPONENT);
		createEAttribute(componentEClass, COMPONENT__NAME);
		createEReference(componentEClass, COMPONENT__COMPONENT);
		createEReference(componentEClass, COMPONENT__NEXT_COMPONENT);

		linearClassifierMixinEClass = createEClass(LINEAR_CLASSIFIER_MIXIN);

		baseMultilayerPerceptronEClass = createEClass(BASE_MULTILAYER_PERCEPTRON);

		baseEstimatorEClass = createEClass(BASE_ESTIMATOR);

		classifierMixinEClass = createEClass(CLASSIFIER_MIXIN);

		regressorMixinEClass = createEClass(REGRESSOR_MIXIN);

		baseOptimizerEClass = createEClass(BASE_OPTIMIZER);

		linearRegressionEClass = createEClass(LINEAR_REGRESSION);

		sgdClassifierEClass = createEClass(SGD_CLASSIFIER);

		sgdRegressorEClass = createEClass(SGD_REGRESSOR);

		mlpClassifierEClass = createEClass(MLP_CLASSIFIER);

		mlpRegressorEClass = createEClass(MLP_REGRESSOR);

		adamOptimizerEClass = createEClass(ADAM_OPTIMIZER);

		sgdOptimizerEClass = createEClass(SGD_OPTIMIZER);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		linearClassifierMixinEClass.getESuperTypes().add(this.getcomponent());
		baseMultilayerPerceptronEClass.getESuperTypes().add(this.getBaseEstimator());
		baseEstimatorEClass.getESuperTypes().add(this.getcomponent());
		classifierMixinEClass.getESuperTypes().add(this.getcomponent());
		regressorMixinEClass.getESuperTypes().add(this.getcomponent());
		baseOptimizerEClass.getESuperTypes().add(this.getcomponent());
		linearRegressionEClass.getESuperTypes().add(this.getLinearClassifierMixin());
		sgdClassifierEClass.getESuperTypes().add(this.getLinearClassifierMixin());
		sgdRegressorEClass.getESuperTypes().add(this.getLinearClassifierMixin());
		mlpClassifierEClass.getESuperTypes().add(this.getBaseMultilayerPerceptron());
		mlpClassifierEClass.getESuperTypes().add(this.getClassifierMixin());
		mlpRegressorEClass.getESuperTypes().add(this.getBaseMultilayerPerceptron());
		mlpRegressorEClass.getESuperTypes().add(this.getRegressorMixin());
		adamOptimizerEClass.getESuperTypes().add(this.getBaseOptimizer());
		sgdOptimizerEClass.getESuperTypes().add(this.getBaseOptimizer());

		// Initialize classes, features, and operations; add parameters
		initEClass(skLearnnEClass, SKLearnn.class, "SKLearnn", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSKLearnn_Name(), ecorePackage.getEString(), "name", null, 0, 1, SKLearnn.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSKLearnn_Component(), this.getcomponent(), null, "component", null, 0, -1, SKLearnn.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(componentEClass, component.class, "component", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getcomponent_Name(), ecorePackage.getEString(), "name", null, 0, 1, component.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getcomponent_Component(), this.getcomponent(), this.getcomponent_NextComponent(), "component",
				null, 0, 1, component.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getcomponent_NextComponent(), this.getcomponent(), this.getcomponent_Component(),
				"NextComponent", null, 0, 1, component.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(linearClassifierMixinEClass, LinearClassifierMixin.class, "LinearClassifierMixin", IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(baseMultilayerPerceptronEClass, BaseMultilayerPerceptron.class, "BaseMultilayerPerceptron",
				IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(baseEstimatorEClass, BaseEstimator.class, "BaseEstimator", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(classifierMixinEClass, ClassifierMixin.class, "ClassifierMixin", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(regressorMixinEClass, RegressorMixin.class, "RegressorMixin", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(baseOptimizerEClass, BaseOptimizer.class, "BaseOptimizer", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(linearRegressionEClass, LinearRegression.class, "LinearRegression", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(sgdClassifierEClass, SGDClassifier.class, "SGDClassifier", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(sgdRegressorEClass, SGDRegressor.class, "SGDRegressor", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(mlpClassifierEClass, MLPClassifier.class, "MLPClassifier", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(mlpRegressorEClass, MLPRegressor.class, "MLPRegressor", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(adamOptimizerEClass, AdamOptimizer.class, "AdamOptimizer", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(sgdOptimizerEClass, SGDOptimizer.class, "SGDOptimizer", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);
	}

} //SklearnnnPackageImpl
