/**
 */
package sklearnnn.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import sklearnnn.SklearnnnPackage;
import sklearnnn.component;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>component</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link sklearnnn.impl.componentImpl#getName <em>Name</em>}</li>
 *   <li>{@link sklearnnn.impl.componentImpl#getComponent <em>Component</em>}</li>
 *   <li>{@link sklearnnn.impl.componentImpl#getNextComponent <em>Next Component</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class componentImpl extends MinimalEObjectImpl.Container implements component {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getComponent() <em>Component</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getComponent()
	 * @generated
	 * @ordered
	 */
	protected component component;

	/**
	 * The cached value of the '{@link #getNextComponent() <em>Next Component</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNextComponent()
	 * @generated
	 * @ordered
	 */
	protected component nextComponent;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected componentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SklearnnnPackage.Literals.COMPONENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SklearnnnPackage.COMPONENT__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public component getComponent() {
		if (component != null && component.eIsProxy()) {
			InternalEObject oldComponent = (InternalEObject) component;
			component = (component) eResolveProxy(oldComponent);
			if (component != oldComponent) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, SklearnnnPackage.COMPONENT__COMPONENT,
							oldComponent, component));
			}
		}
		return component;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public component basicGetComponent() {
		return component;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetComponent(component newComponent, NotificationChain msgs) {
		component oldComponent = component;
		component = newComponent;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					SklearnnnPackage.COMPONENT__COMPONENT, oldComponent, newComponent);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setComponent(component newComponent) {
		if (newComponent != component) {
			NotificationChain msgs = null;
			if (component != null)
				msgs = ((InternalEObject) component).eInverseRemove(this, SklearnnnPackage.COMPONENT__NEXT_COMPONENT,
						component.class, msgs);
			if (newComponent != null)
				msgs = ((InternalEObject) newComponent).eInverseAdd(this, SklearnnnPackage.COMPONENT__NEXT_COMPONENT,
						component.class, msgs);
			msgs = basicSetComponent(newComponent, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SklearnnnPackage.COMPONENT__COMPONENT, newComponent,
					newComponent));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public component getNextComponent() {
		if (nextComponent != null && nextComponent.eIsProxy()) {
			InternalEObject oldNextComponent = (InternalEObject) nextComponent;
			nextComponent = (component) eResolveProxy(oldNextComponent);
			if (nextComponent != oldNextComponent) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							SklearnnnPackage.COMPONENT__NEXT_COMPONENT, oldNextComponent, nextComponent));
			}
		}
		return nextComponent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public component basicGetNextComponent() {
		return nextComponent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetNextComponent(component newNextComponent, NotificationChain msgs) {
		component oldNextComponent = nextComponent;
		nextComponent = newNextComponent;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					SklearnnnPackage.COMPONENT__NEXT_COMPONENT, oldNextComponent, newNextComponent);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNextComponent(component newNextComponent) {
		if (newNextComponent != nextComponent) {
			NotificationChain msgs = null;
			if (nextComponent != null)
				msgs = ((InternalEObject) nextComponent).eInverseRemove(this, SklearnnnPackage.COMPONENT__COMPONENT,
						component.class, msgs);
			if (newNextComponent != null)
				msgs = ((InternalEObject) newNextComponent).eInverseAdd(this, SklearnnnPackage.COMPONENT__COMPONENT,
						component.class, msgs);
			msgs = basicSetNextComponent(newNextComponent, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SklearnnnPackage.COMPONENT__NEXT_COMPONENT,
					newNextComponent, newNextComponent));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case SklearnnnPackage.COMPONENT__COMPONENT:
			if (component != null)
				msgs = ((InternalEObject) component).eInverseRemove(this, SklearnnnPackage.COMPONENT__NEXT_COMPONENT,
						component.class, msgs);
			return basicSetComponent((component) otherEnd, msgs);
		case SklearnnnPackage.COMPONENT__NEXT_COMPONENT:
			if (nextComponent != null)
				msgs = ((InternalEObject) nextComponent).eInverseRemove(this, SklearnnnPackage.COMPONENT__COMPONENT,
						component.class, msgs);
			return basicSetNextComponent((component) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case SklearnnnPackage.COMPONENT__COMPONENT:
			return basicSetComponent(null, msgs);
		case SklearnnnPackage.COMPONENT__NEXT_COMPONENT:
			return basicSetNextComponent(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case SklearnnnPackage.COMPONENT__NAME:
			return getName();
		case SklearnnnPackage.COMPONENT__COMPONENT:
			if (resolve)
				return getComponent();
			return basicGetComponent();
		case SklearnnnPackage.COMPONENT__NEXT_COMPONENT:
			if (resolve)
				return getNextComponent();
			return basicGetNextComponent();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case SklearnnnPackage.COMPONENT__NAME:
			setName((String) newValue);
			return;
		case SklearnnnPackage.COMPONENT__COMPONENT:
			setComponent((component) newValue);
			return;
		case SklearnnnPackage.COMPONENT__NEXT_COMPONENT:
			setNextComponent((component) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case SklearnnnPackage.COMPONENT__NAME:
			setName(NAME_EDEFAULT);
			return;
		case SklearnnnPackage.COMPONENT__COMPONENT:
			setComponent((component) null);
			return;
		case SklearnnnPackage.COMPONENT__NEXT_COMPONENT:
			setNextComponent((component) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case SklearnnnPackage.COMPONENT__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case SklearnnnPackage.COMPONENT__COMPONENT:
			return component != null;
		case SklearnnnPackage.COMPONENT__NEXT_COMPONENT:
			return nextComponent != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //componentImpl
