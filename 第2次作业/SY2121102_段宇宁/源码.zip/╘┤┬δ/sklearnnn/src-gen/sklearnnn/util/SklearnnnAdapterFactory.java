/**
 */
package sklearnnn.util;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

import sklearnnn.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see sklearnnn.SklearnnnPackage
 * @generated
 */
public class SklearnnnAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static SklearnnnPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SklearnnnAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = SklearnnnPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SklearnnnSwitch<Adapter> modelSwitch = new SklearnnnSwitch<Adapter>() {
		@Override
		public Adapter caseSKLearnn(SKLearnn object) {
			return createSKLearnnAdapter();
		}

		@Override
		public Adapter casecomponent(component object) {
			return createcomponentAdapter();
		}

		@Override
		public Adapter caseLinearClassifierMixin(LinearClassifierMixin object) {
			return createLinearClassifierMixinAdapter();
		}

		@Override
		public Adapter caseBaseMultilayerPerceptron(BaseMultilayerPerceptron object) {
			return createBaseMultilayerPerceptronAdapter();
		}

		@Override
		public Adapter caseBaseEstimator(BaseEstimator object) {
			return createBaseEstimatorAdapter();
		}

		@Override
		public Adapter caseClassifierMixin(ClassifierMixin object) {
			return createClassifierMixinAdapter();
		}

		@Override
		public Adapter caseRegressorMixin(RegressorMixin object) {
			return createRegressorMixinAdapter();
		}

		@Override
		public Adapter caseBaseOptimizer(BaseOptimizer object) {
			return createBaseOptimizerAdapter();
		}

		@Override
		public Adapter caseLinearRegression(LinearRegression object) {
			return createLinearRegressionAdapter();
		}

		@Override
		public Adapter caseSGDClassifier(SGDClassifier object) {
			return createSGDClassifierAdapter();
		}

		@Override
		public Adapter caseSGDRegressor(SGDRegressor object) {
			return createSGDRegressorAdapter();
		}

		@Override
		public Adapter caseMLPClassifier(MLPClassifier object) {
			return createMLPClassifierAdapter();
		}

		@Override
		public Adapter caseMLPRegressor(MLPRegressor object) {
			return createMLPRegressorAdapter();
		}

		@Override
		public Adapter caseAdamOptimizer(AdamOptimizer object) {
			return createAdamOptimizerAdapter();
		}

		@Override
		public Adapter caseSGDOptimizer(SGDOptimizer object) {
			return createSGDOptimizerAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link sklearnnn.SKLearnn <em>SK Learnn</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see sklearnnn.SKLearnn
	 * @generated
	 */
	public Adapter createSKLearnnAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link sklearnnn.component <em>component</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see sklearnnn.component
	 * @generated
	 */
	public Adapter createcomponentAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link sklearnnn.LinearClassifierMixin <em>Linear Classifier Mixin</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see sklearnnn.LinearClassifierMixin
	 * @generated
	 */
	public Adapter createLinearClassifierMixinAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link sklearnnn.BaseMultilayerPerceptron <em>Base Multilayer Perceptron</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see sklearnnn.BaseMultilayerPerceptron
	 * @generated
	 */
	public Adapter createBaseMultilayerPerceptronAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link sklearnnn.BaseEstimator <em>Base Estimator</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see sklearnnn.BaseEstimator
	 * @generated
	 */
	public Adapter createBaseEstimatorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link sklearnnn.ClassifierMixin <em>Classifier Mixin</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see sklearnnn.ClassifierMixin
	 * @generated
	 */
	public Adapter createClassifierMixinAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link sklearnnn.RegressorMixin <em>Regressor Mixin</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see sklearnnn.RegressorMixin
	 * @generated
	 */
	public Adapter createRegressorMixinAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link sklearnnn.BaseOptimizer <em>Base Optimizer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see sklearnnn.BaseOptimizer
	 * @generated
	 */
	public Adapter createBaseOptimizerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link sklearnnn.LinearRegression <em>Linear Regression</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see sklearnnn.LinearRegression
	 * @generated
	 */
	public Adapter createLinearRegressionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link sklearnnn.SGDClassifier <em>SGD Classifier</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see sklearnnn.SGDClassifier
	 * @generated
	 */
	public Adapter createSGDClassifierAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link sklearnnn.SGDRegressor <em>SGD Regressor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see sklearnnn.SGDRegressor
	 * @generated
	 */
	public Adapter createSGDRegressorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link sklearnnn.MLPClassifier <em>MLP Classifier</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see sklearnnn.MLPClassifier
	 * @generated
	 */
	public Adapter createMLPClassifierAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link sklearnnn.MLPRegressor <em>MLP Regressor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see sklearnnn.MLPRegressor
	 * @generated
	 */
	public Adapter createMLPRegressorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link sklearnnn.AdamOptimizer <em>Adam Optimizer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see sklearnnn.AdamOptimizer
	 * @generated
	 */
	public Adapter createAdamOptimizerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link sklearnnn.SGDOptimizer <em>SGD Optimizer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see sklearnnn.SGDOptimizer
	 * @generated
	 */
	public Adapter createSGDOptimizerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //SklearnnnAdapterFactory
