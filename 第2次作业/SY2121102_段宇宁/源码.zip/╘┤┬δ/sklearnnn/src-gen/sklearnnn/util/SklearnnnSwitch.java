/**
 */
package sklearnnn.util;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

import sklearnnn.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see sklearnnn.SklearnnnPackage
 * @generated
 */
public class SklearnnnSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static SklearnnnPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SklearnnnSwitch() {
		if (modelPackage == null) {
			modelPackage = SklearnnnPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case SklearnnnPackage.SK_LEARNN: {
			SKLearnn skLearnn = (SKLearnn) theEObject;
			T result = caseSKLearnn(skLearnn);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SklearnnnPackage.COMPONENT: {
			component component = (component) theEObject;
			T result = casecomponent(component);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SklearnnnPackage.LINEAR_CLASSIFIER_MIXIN: {
			LinearClassifierMixin linearClassifierMixin = (LinearClassifierMixin) theEObject;
			T result = caseLinearClassifierMixin(linearClassifierMixin);
			if (result == null)
				result = casecomponent(linearClassifierMixin);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SklearnnnPackage.BASE_MULTILAYER_PERCEPTRON: {
			BaseMultilayerPerceptron baseMultilayerPerceptron = (BaseMultilayerPerceptron) theEObject;
			T result = caseBaseMultilayerPerceptron(baseMultilayerPerceptron);
			if (result == null)
				result = caseBaseEstimator(baseMultilayerPerceptron);
			if (result == null)
				result = casecomponent(baseMultilayerPerceptron);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SklearnnnPackage.BASE_ESTIMATOR: {
			BaseEstimator baseEstimator = (BaseEstimator) theEObject;
			T result = caseBaseEstimator(baseEstimator);
			if (result == null)
				result = casecomponent(baseEstimator);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SklearnnnPackage.CLASSIFIER_MIXIN: {
			ClassifierMixin classifierMixin = (ClassifierMixin) theEObject;
			T result = caseClassifierMixin(classifierMixin);
			if (result == null)
				result = casecomponent(classifierMixin);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SklearnnnPackage.REGRESSOR_MIXIN: {
			RegressorMixin regressorMixin = (RegressorMixin) theEObject;
			T result = caseRegressorMixin(regressorMixin);
			if (result == null)
				result = casecomponent(regressorMixin);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SklearnnnPackage.BASE_OPTIMIZER: {
			BaseOptimizer baseOptimizer = (BaseOptimizer) theEObject;
			T result = caseBaseOptimizer(baseOptimizer);
			if (result == null)
				result = casecomponent(baseOptimizer);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SklearnnnPackage.LINEAR_REGRESSION: {
			LinearRegression linearRegression = (LinearRegression) theEObject;
			T result = caseLinearRegression(linearRegression);
			if (result == null)
				result = caseLinearClassifierMixin(linearRegression);
			if (result == null)
				result = casecomponent(linearRegression);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SklearnnnPackage.SGD_CLASSIFIER: {
			SGDClassifier sgdClassifier = (SGDClassifier) theEObject;
			T result = caseSGDClassifier(sgdClassifier);
			if (result == null)
				result = caseLinearClassifierMixin(sgdClassifier);
			if (result == null)
				result = casecomponent(sgdClassifier);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SklearnnnPackage.SGD_REGRESSOR: {
			SGDRegressor sgdRegressor = (SGDRegressor) theEObject;
			T result = caseSGDRegressor(sgdRegressor);
			if (result == null)
				result = caseLinearClassifierMixin(sgdRegressor);
			if (result == null)
				result = casecomponent(sgdRegressor);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SklearnnnPackage.MLP_CLASSIFIER: {
			MLPClassifier mlpClassifier = (MLPClassifier) theEObject;
			T result = caseMLPClassifier(mlpClassifier);
			if (result == null)
				result = caseBaseMultilayerPerceptron(mlpClassifier);
			if (result == null)
				result = caseClassifierMixin(mlpClassifier);
			if (result == null)
				result = caseBaseEstimator(mlpClassifier);
			if (result == null)
				result = casecomponent(mlpClassifier);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SklearnnnPackage.MLP_REGRESSOR: {
			MLPRegressor mlpRegressor = (MLPRegressor) theEObject;
			T result = caseMLPRegressor(mlpRegressor);
			if (result == null)
				result = caseBaseMultilayerPerceptron(mlpRegressor);
			if (result == null)
				result = caseRegressorMixin(mlpRegressor);
			if (result == null)
				result = caseBaseEstimator(mlpRegressor);
			if (result == null)
				result = casecomponent(mlpRegressor);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SklearnnnPackage.ADAM_OPTIMIZER: {
			AdamOptimizer adamOptimizer = (AdamOptimizer) theEObject;
			T result = caseAdamOptimizer(adamOptimizer);
			if (result == null)
				result = caseBaseOptimizer(adamOptimizer);
			if (result == null)
				result = casecomponent(adamOptimizer);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SklearnnnPackage.SGD_OPTIMIZER: {
			SGDOptimizer sgdOptimizer = (SGDOptimizer) theEObject;
			T result = caseSGDOptimizer(sgdOptimizer);
			if (result == null)
				result = caseBaseOptimizer(sgdOptimizer);
			if (result == null)
				result = casecomponent(sgdOptimizer);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>SK Learnn</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>SK Learnn</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSKLearnn(SKLearnn object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>component</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>component</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casecomponent(component object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Linear Classifier Mixin</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Linear Classifier Mixin</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLinearClassifierMixin(LinearClassifierMixin object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Base Multilayer Perceptron</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Base Multilayer Perceptron</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBaseMultilayerPerceptron(BaseMultilayerPerceptron object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Base Estimator</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Base Estimator</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBaseEstimator(BaseEstimator object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Classifier Mixin</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Classifier Mixin</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseClassifierMixin(ClassifierMixin object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Regressor Mixin</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Regressor Mixin</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRegressorMixin(RegressorMixin object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Base Optimizer</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Base Optimizer</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBaseOptimizer(BaseOptimizer object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Linear Regression</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Linear Regression</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLinearRegression(LinearRegression object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>SGD Classifier</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>SGD Classifier</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSGDClassifier(SGDClassifier object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>SGD Regressor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>SGD Regressor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSGDRegressor(SGDRegressor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>MLP Classifier</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>MLP Classifier</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMLPClassifier(MLPClassifier object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>MLP Regressor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>MLP Regressor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMLPRegressor(MLPRegressor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Adam Optimizer</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Adam Optimizer</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAdamOptimizer(AdamOptimizer object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>SGD Optimizer</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>SGD Optimizer</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSGDOptimizer(SGDOptimizer object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //SklearnnnSwitch
